Techmarket - Clean, smart, robust and flexible WordPress theme with vertical and horizontal menu variants – ideal for any type of eCommerce Shop.

The theme's documentation and the customer support are provided online. Here are a few useful links on getting started with the theme.

1. Theme Documentation - https://docs.madrasthemes.com/techmarket/
2. Support Email - https://themeforest.net/item/techmarket-multidemo-electronics-store-woocommerce-theme/20241155/support
3. Getting Started with WooCommerce - https://docs.woothemes.com/documentation/plugins/woocommerce/getting-started/
4. Getting Started with Wordpress - https://codex.wordpress.org/Getting_Started_with_WordPress