<?php

techmarket_get_template( 'global/tech-logo.php' );