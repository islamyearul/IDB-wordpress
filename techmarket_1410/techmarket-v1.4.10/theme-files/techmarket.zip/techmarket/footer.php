<?php
/**
 * The template for displaying the footer.
 *
 * @package techmarket
 */

$footer_version = techmarket_get_footer_version();

get_footer( $footer_version ); ?>