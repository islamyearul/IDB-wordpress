<?php
/**
 * The header for our theme.
 *
 * @package techmarket
 */

$header_version = techmarket_get_header_version();

get_header( $header_version ); ?>