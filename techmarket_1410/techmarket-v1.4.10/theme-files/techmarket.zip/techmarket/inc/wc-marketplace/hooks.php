<?php
/**
 * All WC Marketplace Related functions
 */

add_action( 'wp_enqueue_scripts', 'techmarket_wc_marketplace_scripts', 20 );