Techmarket
==============================
Techmarket is an answer for new trends in full resolution designs. Clean, smart, robust and flexible WordPress theme with vertical and horizontal menu variants – ideal for any type of eCommerce Shop. This theme is brought to you by the same team that developed Electro, MediaCenter, Pizzaro and MyBag.

It features deep integration with WooCommerce core plus several of the most popular extensions:

King Composer
Visual Composer (not included with the theme)
Slider Revolution
YITH WooCommerce Compare
YITH WooCommerce Wishlist

The codebase of Techmarket is lean and extensible which will allow develoepers to easily add functionality to your site via child theme and/or custom plugin(s).

Techmarket Documentation
==============================
You can view detailed Techmarket documentation on the Techmarket documentation web site.

Techmarket help & support
==============================
MadrasThemes customers can get support at the Madras Themes support portal.